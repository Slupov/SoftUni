let Entity = require('./entity').Entity;
let Person = require('./person').Person;
let Dog = require('./dog').Dog;
let Student = require('./student').Student;

result.Entity = Entity;
result.Person = Person;
result.Dog = Dog;
result.Student = Student;