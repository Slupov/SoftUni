let mapSort = require('./helper-functions').mapSort;

result.mapSort = mapSort;