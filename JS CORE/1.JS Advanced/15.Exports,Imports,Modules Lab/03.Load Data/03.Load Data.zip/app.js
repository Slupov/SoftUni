let functions = require('./template');

//debugging
// console.log(functions.filter('status', 'shipped'));

result.sort = functions.sort;
result.filter = functions.filter;