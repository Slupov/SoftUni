let Employee = require('./modules/employee.js').Employee;
let Manager = require('./modules/manager.js').Manager;
let Senior = require('./modules/senior.js').Senior;
let Junior = require('./modules/junior.js').Junior;

result.Employee = Employee;
result.Manager = Manager;
result.Senior = Senior;
result.Junior = Junior;
