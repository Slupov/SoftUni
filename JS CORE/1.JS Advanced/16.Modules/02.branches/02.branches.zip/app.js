let Branch = require('./modules/branch.js').Branch;
let Employee = require('./modules/employee.js').Employee;

result.Branch = Branch;
result.Employee = Employee;
