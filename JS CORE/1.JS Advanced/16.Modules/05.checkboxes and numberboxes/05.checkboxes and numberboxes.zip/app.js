let Checkbox = require('./modules/checkbox.js').Checkbox;
let Numberbox = require('./modules/numberbox.js').Numberbox;

result.Checkbox = Checkbox;
result.Numberbox = Numberbox;
