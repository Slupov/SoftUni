let Turtle = require('./modules/turtle.js').Turtle;
let EvkodianTurtle = require('./modules/evkodian-turtle.js').EvkodianTurtle;
let GalapagosTurtle = require('./modules/galapagos-turtle.js').GalapagosTurtle;
let WaterTurtle = require('./modules/water-turtle.js').WaterTurtle;
let NinjaTurtle = require('./modules/ninja-turtle.js').NinjaTurtle;

result.Turtle = Turtle;
result.EvkodianTurtle = EvkodianTurtle;
result.GalapagosTurtle = GalapagosTurtle;
result.WaterTurtle = WaterTurtle;
result.NinjaTurtle = NinjaTurtle;
