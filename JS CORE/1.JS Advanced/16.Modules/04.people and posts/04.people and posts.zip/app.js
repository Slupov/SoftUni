let Person = require('./modules/person.js').Person;
let Post = require('./modules/post.js').Post;

result.Person = Person;
result.Post = Post;
