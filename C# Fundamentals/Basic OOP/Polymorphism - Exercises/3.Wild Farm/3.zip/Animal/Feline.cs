﻿namespace _3.Wild_Farm.Animal
{
    abstract class Feline : Mammal
    {

    }
}
