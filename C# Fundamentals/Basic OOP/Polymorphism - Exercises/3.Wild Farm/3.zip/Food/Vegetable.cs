﻿namespace _3.Wild_Farm.Food
{
    class Vegetable : Food
    {
        public Vegetable(int quantity) : base(quantity)
        {
        }
    }
}
