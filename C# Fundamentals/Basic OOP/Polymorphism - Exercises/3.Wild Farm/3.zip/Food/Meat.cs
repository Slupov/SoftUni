﻿namespace _3.Wild_Farm.Food
{
    class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}