﻿namespace Polymorphism___Exercises
{
    class Car : Vehicle
    {
        public Car(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumptionPerKm = fuelConsumption;
            IncreaseConsumption(0.9);
        }
    }
}
