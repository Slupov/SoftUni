﻿
namespace Polymorphism___Exercises
{
    using System;
    abstract class Vehicle
    {
        protected double FuelQuantity { get; set; }
        protected double FuelConsumptionPerKm { get; set; }

        public virtual void Drive(double kms)
        {
            if (CanTravel(kms))
            {
                FuelQuantity -= FuelConsumptionPerKm * kms;
                Console.WriteLine("{0} travelled {1} km", this.GetType().Name, kms);
            }
            else
            {

                Console.WriteLine("{0} needs refueling", this.GetType().Name);
            }
        }

        public virtual void Refuel(double fuel)
        {
            this.FuelQuantity += fuel;
        }

        protected virtual void IncreaseConsumption(double increaseValue)
        {
            this.FuelConsumptionPerKm += increaseValue;
        }

        protected bool CanTravel(double kms)
        {
            if (FuelConsumptionPerKm * kms > FuelQuantity)
            {
                return false;
            }

            return true;
        }

        public override string ToString()
        {
            return $"{this.GetType().Name}: {this.FuelQuantity:F2}";
        }
    }
}