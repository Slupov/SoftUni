﻿using System;

public abstract class Provider
{
    protected Provider(string id, double energyOutput)
    {
        Id = id;
        EnergyOutput = energyOutput;
    }

    private string id;

    public string Id
    {
        get { return id; }
        protected set { id = value; }
    }

    private double energyOutput;

    public double EnergyOutput
    {
        get { return energyOutput; }
        protected set
        {
            if (value >= 0 && value < 10000)
            {
                energyOutput = value;
            }
            else
            {
                throw new ArgumentException("Provider is not registered, because of it's energyOutput");
            }
        }
    }
}