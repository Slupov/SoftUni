﻿using System.Collections.Generic;

public class DraftManager
{
    private List<Harvester> harvesters;

    public List<Harvester> Harvesters
    {
        get { return harvesters; }
        set { harvesters = value; }
    }

    private List<Provider> providers;

    public List<Provider> Providers
    {
        get { return providers; }
        set { providers = value; }
    }

    public DraftManager()
    {
        Harvesters = new List<Harvester>();
        Providers = new List<Provider>();
    }

    public string RegisterHarvester(List<string> arguments)
    {
        Harvester harvester;
        var type = arguments[0];
        var id = arguments[1];
        var oreOutput = double.Parse(arguments[2]);
        var energyRequirement = double.Parse(arguments[3]);

        if (type == "Sonic")
        {
            var sonicFactor = int.Parse(arguments[4]);
            harvester = new SonicHarvester(id,oreOutput,energyRequirement,sonicFactor);
        }
        else
        {
            harvester = new HammerHarvester(id,oreOutput,energyRequirement);
        }

        Harvesters.Add(harvester);

        return $"Successfully registered {type} Harvester – {id}";
    }

    public string RegisterProvider(List<string> arguments)
    {

        Provider provider;
        var type = arguments[0];
        var id = arguments[1];
        var energyOutput = double.Parse(arguments[2]);

        if (type == "Pressure")
        {
            provider = new PressureProvider(id,energyOutput);
        }
        else
        {
            provider = new SolarProvider(id,energyOutput);
        }

        Providers.Add(provider);
        return $"Successfully registered {type} Provider – {id}";
    }

    public string Day()
    {
        //TODO: Add some logic here …
        return string.Empty;
    }

    public string Mode(List<string> arguments)
    {
        //TODO: Add some logic here …
        return string.Empty;
    }

    public string Check(List<string> arguments)
    {
        //TODO: Add some logic here …
        return string.Empty;
    }

    public string ShutDown()
    {
        //TODO: Add some logic here …
        return string.Empty;
    }
}