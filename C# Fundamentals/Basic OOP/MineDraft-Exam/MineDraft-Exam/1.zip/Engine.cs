﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Engine
{
    private DraftManager draftManager;

    public Engine()
    {
        this.draftManager = new DraftManager();
    }

    public void Run()
    {
        var tokens = ParseInput(Console.ReadLine());

        string command = string.Empty;

        while ((command = tokens[0]) != "Quit")
        {
            ProcessCommand(command, tokens.Skip(1).ToList());
            tokens = ParseInput(Console.ReadLine());
        }
    }

    private void ProcessCommand(string command, List<string> commandArgs)
    {
        switch (command)
        {
            case "RegisterHarvester":
                this.draftManager.RegisterHarvester(commandArgs);
                break;
            case "RegisterProvider":
                this.draftManager.RegisterHarvester(commandArgs);
                break;
            case "Day":
                this.draftManager.RegisterHarvester(commandArgs);
                break;
            case "Mode":
                this.draftManager.RegisterHarvester(commandArgs);
                break;
            case "Check":
                this.draftManager.RegisterHarvester(commandArgs);
                break;
            case "Shutdown":
                this.draftManager.RegisterHarvester(commandArgs);
                break;
            default:
                throw new InvalidOperationException("No such command exists");
        }
    }

    private List<string> ParseInput(string input)
    {
        return input.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).ToList();
    }
}