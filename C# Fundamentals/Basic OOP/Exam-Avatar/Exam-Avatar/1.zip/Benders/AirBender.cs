﻿public class AirBender : Bender
{
    private double aerialIntegrity;

    public double AerialIntegrity
    {
        get { return aerialIntegrity; }
        set { aerialIntegrity = value; }
    }

    public override double TotalPower
    {
        get { return Power * AerialIntegrity; }
    }
}