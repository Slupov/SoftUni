﻿public class FireBender : Bender
{
    private double heatAggression;

    public double HeatAggression
    {
        get { return heatAggression; }
        set { heatAggression = value; }
    }

    public override double TotalPower
    {
        get { return Power * HeatAggression; }
    }
}