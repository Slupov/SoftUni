﻿public class WaterBender : Bender
{
    private double waterClarity;
    public double WaterClarity
    {
        get { return waterClarity; }
        set { waterClarity = value; }
    }
}