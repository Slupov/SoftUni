﻿public class EarthBender : Bender
{
    private double groundSaturation;

    public double GroundSaturation
    {
        get { return groundSaturation; }
        set { groundSaturation = value; }
    }

    public override double TotalPower
    {
        get { return Power * GroundSaturation; }
    }
}