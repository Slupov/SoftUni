﻿using System.Collections.Generic;

class NationsBuilder
{
    void AssignBender(List<string> benderArgs)
    {
        //TODO: Add some logic here … 
    }

    void AssignMonument(List<string> monumentArgs)
    {
        //TODO: Add some logic here … 
    }

    string GetStatus(string nationsType)
    {
        //TODO: Add some logic here … 
    }

    void IssueWar(string nationsType)
    {
        //TODO: Add some logic here … 
    }

    string GetWarsRecord()
    {
        //TODO: Add some logic here … 
    }
}