﻿public class WaterMonument : Monument
{
    private int waterAffinity;

    public int WaterAffinity
    {
        get { return waterAffinity; }
        set { waterAffinity = value; }
    }

    public override int Affinity
    {
        get { return WaterAffinity; }
    }
}