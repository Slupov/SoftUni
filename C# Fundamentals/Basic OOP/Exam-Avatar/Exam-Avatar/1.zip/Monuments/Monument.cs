﻿public abstract class Monument
{
    private string name;
    protected string Name
    {
        get { return name; }
        set { name = value; }
    }

    public virtual int Affinity
    {
        get { return 0; }
    }
}