﻿public class FireMonument : Monument
{
    private int fireAffinity;

    public int FireAffinity
    {
        get { return fireAffinity; }
        set { fireAffinity = value; }
    }

    public override int Affinity
    {
        get { return FireAffinity; }
    }
}