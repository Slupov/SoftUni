﻿public class AirMonument : Monument
{
    private int airAffinity;

    public int AirAffinity
    {
        get { return airAffinity; }
        set { airAffinity = value; }
    }

    public override int Affinity
    {
        get { return AirAffinity; }
    }
}