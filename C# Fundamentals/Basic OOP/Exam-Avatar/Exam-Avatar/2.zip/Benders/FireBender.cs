﻿public class FireBender : Bender
{
    public FireBender(string name, int power, double secondary) : base(name, power)
    {
        HeatAggression = secondary;
    }

    private double heatAggression;

    public double HeatAggression
    {
        get { return heatAggression; }
        set { heatAggression = value; }
    }

    public override double TotalPower
    {
        get { return Power * HeatAggression; }
    }
}