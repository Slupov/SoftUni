﻿public class WaterBender : Bender
{
    public WaterBender(string name, int power, double secondary) : base(name, power)
    {
        WaterClarity = secondary;
    }

    private double waterClarity;

    public double WaterClarity
    {
        get { return waterClarity; }
        set { waterClarity = value; }
    }
}