﻿public class EarthBender : Bender
{
    public EarthBender(string name, int power, double secondary) : base(name, power)
    {
        GroundSaturation = secondary;
    }

    private double groundSaturation;

    public double GroundSaturation
    {
        get { return groundSaturation; }
        set { groundSaturation = value; }
    }

    public override double TotalPower
    {
        get { return Power * GroundSaturation; }
    }
}