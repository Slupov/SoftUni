﻿using System;
using System.Collections.Generic;
using System.Text;

public abstract class Race
{
    protected Race(int length, string route, int prizePool, List<Car> participants)
    {
        Length = length;
        Route = route;
        PrizePool = prizePool;
        Participants = participants;
    }

    private int length;

    protected int Length
    {
        get { return length; }
        set { length = value; }
    }

    private string route;

    protected string Route
    {
        get { return route; }
        set { route = value; }
    }

    private int prizePool;

    protected int PrizePool
    {
        get { return prizePool; }
        set { prizePool = value; }
    }

    private List<Car> participants;

    protected List<Car> Participants
    {
        get { return participants; }
        set { participants = value; }
    }

    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine($"{this.Route} - {this.Length}");

        if (Participants.Count > 0)
        {
            for (int i = 0; i < Participants.Count; i++)
            {
                throw new NotImplementedException();
            }
        }

        return sb.ToString();
    }
}