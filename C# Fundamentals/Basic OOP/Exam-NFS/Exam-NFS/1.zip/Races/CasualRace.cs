﻿using System.Collections.Generic;

class CasualRace : Race
{
    public CasualRace(int length, string route, int prizePool, List<Car> participants) : base(length, route, prizePool, participants)
    {
    }
}