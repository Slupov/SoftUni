﻿namespace InfernoInfinity.Interfaces
{
    public interface IDmgBoost
    {
        int MaxDamageBoost { get; }
        int MinDamageBoost { get; }
    }
}