﻿namespace InfernoInfinity.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}