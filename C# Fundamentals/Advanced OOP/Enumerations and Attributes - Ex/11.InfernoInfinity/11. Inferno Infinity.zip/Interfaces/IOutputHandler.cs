﻿namespace InfernoInfinity.Interfaces
{
    public interface IOutputHandler
    {
        void PrintLine(string line);
    }
}