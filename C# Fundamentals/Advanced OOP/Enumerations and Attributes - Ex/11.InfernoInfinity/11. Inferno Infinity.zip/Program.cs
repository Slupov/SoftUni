﻿using InfernoInfinity.Core;

namespace InfernoInfinity
{
    internal class Startup
    {
        private static void Main(string[] args)
        {
            var engine = new Engine();

            engine.Run();
        }
    }
}