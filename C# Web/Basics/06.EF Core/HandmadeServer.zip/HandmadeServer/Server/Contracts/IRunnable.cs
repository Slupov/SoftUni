﻿namespace HandmadeServer.Server.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
