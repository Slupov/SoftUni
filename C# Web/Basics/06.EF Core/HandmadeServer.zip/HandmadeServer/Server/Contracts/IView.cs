﻿namespace HandmadeServer.Server.Contracts
{
    public interface IView
    {
        string View();
    }
}
