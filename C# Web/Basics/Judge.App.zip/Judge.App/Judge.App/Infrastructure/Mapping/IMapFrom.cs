﻿namespace Judge.App.Infrastructure.Mapping
{
    public interface IMapFrom<T>
    {
    }
}
