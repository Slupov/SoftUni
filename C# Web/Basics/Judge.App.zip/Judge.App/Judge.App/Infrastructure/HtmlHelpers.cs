﻿namespace Judge.App.Infrastructure
{
    public static class HtmlHelpers
    {
//        public static string ToHtml(this GameListingHomeModel game, bool isAdmin)
//            => $@"
//                <div class=""card col-4 thumbnail"">
//                    <img class=""card-image-top img-fluid img-thumbnail""
//                            onerror=""this.src='https://i.ytimg.com/vi/{game.VideoId}/maxresdefault.jpg';""
//                            src=""{game.ThumbnailUrl}"">
//                    <div class=""card-body"">
//                        <h4 class=""card-title"">{game.Title}</h4>
//                        <p class=""card-text""><strong>Price</strong> - {game.Price}&euro;</p>
//                        <p class=""card-text""><strong>Size</strong> - {game.Size} GB</p>
//                        <p class=""card-text"">{game.Description.Shortify(300)}</p>
//                    </div>
//                    <div class=""card-footer"">
//                        {(!isAdmin ? string.Empty : $@"
//                            <a class=""card-button btn btn-warning"" name=""edit"" href=""/admin/edit?id={game.Id}"">Edit</a>
//                            <a class=""card-button btn btn-danger"" name=""delete"" href=""/admin/delete?id={game.Id}"">Delete</a>
//                        ")}
//                            
//                        <a class=""card-button btn btn-outline-primary"" name=""info"" href=""/games/details?id={game.Id}"">Info</a>
//                        <a class=""card-button btn btn-primary"" name=""buy"" href=""/orders/buy?id={game.Id}"">Buy</a>
//                    </div>
//                </div>";
    }
}